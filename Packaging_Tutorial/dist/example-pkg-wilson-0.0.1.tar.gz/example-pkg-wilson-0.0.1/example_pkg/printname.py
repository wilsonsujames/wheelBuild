

def printFuntest():
    print("I got it")
    return "haha"