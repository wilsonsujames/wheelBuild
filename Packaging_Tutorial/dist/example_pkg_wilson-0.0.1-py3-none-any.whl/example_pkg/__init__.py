def printFuntestIninit():
    print("I got it in Init")
    return "haha init"

